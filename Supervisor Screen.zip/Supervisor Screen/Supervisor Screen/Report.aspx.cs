﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Supervisor_Screen
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Report report = (Report)Request.asdasdasd //get report somehow
            //initializeComponents(report);
        }

        /*
        private void initializeComponents(Report r)
        {
            lblLocation.Text = r.location;
            lblDescription.Text = r.description;
            lblAmount.Text = r.Amount;
            lblCurrency.Text = r.Currency;
            lblSubmitter.Text = r.Submitter;
        }
        */
    }
}