﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlueConsultingBusinessLogic;
using BlueConsultingBusinessLogic.ReportDataSetTableAdapters;

namespace GUI.Consultant
{
    public partial class ConsultantMainGUI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //update the date time using session?
            labelDate.Text = DateTime.Now.ToString();

            ConsultantLogic consultant = (ConsultantLogic)Session["consultant"];
            LinkedList<Report> reports = new LinkedList<Report>();

            if (consultant != null)
            {
                reports = consultant.getAllReports();

                foreach (Report report in reports)
                {
                    String reportData = String.Format("{0}", report.ReportDate); //could add more identifiers?
                    listboxReports.Items.Add(reportData);
                }
            }
            BlueConsultingBusinessLogic.ReportDataSet reportTableAdapter = BlueConsultingBusinessLogic.DatabaseAccess.getReportsByConsultantID(User.Identity.Name);
            //reportDataSet.Reports.
            lblTest.Text = User.Identity.Name;
            var table = new ReportsTableAdapter().GetDataByConsultant(User.Identity.Name);
            GridView1.DataSource = table;
            GridView1.DataBind();
            //lblTest.Text = reportDataSet.;
            //GridView1.Visible = true;
            
        }

        protected void btnCreateReport_Click(object sender, EventArgs e)
        {
            Response.Redirect("ConsultantCreateReport.aspx");
        }

        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            ConsultantLogic consultant = (ConsultantLogic)Session["consultant"];
            
            if (consultant != null)
            {
                //find and print report
                //later on make sure user selected something

                String selectedReport = listboxReports.SelectedItem.ToString();
                Report report = consultant.getReport(selectedReport); //here lies the problem

                if (report != null) //if report is found
                {
                    Session["reportPreview"] = report.getFormattedReport();
                    Response.Redirect("ConsultantShowReport.aspx");
                }
            }
        }
        
    }
}