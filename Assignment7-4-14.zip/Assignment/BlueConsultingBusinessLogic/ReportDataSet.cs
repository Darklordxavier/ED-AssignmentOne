﻿namespace BlueConsultingBusinessLogic {
    
    
    public partial class ReportDataSet {
        private void InitializeComponent()
        {
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // ReportDataSet
            // 
            this.EnforceConstraints = false;
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
    }
}


namespace BlueConsultingBusinessLogic.ReportDataSetTableAdapters {
    
    
    public partial class ReportsTableAdapter {
    }
}
